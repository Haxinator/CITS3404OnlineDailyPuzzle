#imports the main applicate to this file
#which just means it "copies" all the 
#code that belongs to the app variable
#in the app directory to this file.

#Why? Cleaner and more organised files
from app import app