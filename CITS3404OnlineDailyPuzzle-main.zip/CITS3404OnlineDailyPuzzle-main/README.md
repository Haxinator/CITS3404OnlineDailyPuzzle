# CITS3404OnlineDailyPuzzle
Online daily puzzle group project for CITS3404 - Agile Web Development

In addition to the web application, you should create a private GitHub project that includes a readme describing:

1.the purpose of the web application, explaining the design of the game.
2.the architecture of the web application.
3.describe how to launch the web application.
4.describe some unit tests for the web application, and how to run them.
5.Include commit logs, showing contributions and review from both contributing students.
